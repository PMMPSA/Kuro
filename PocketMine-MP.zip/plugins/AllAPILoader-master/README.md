# AllAPILoader
A PocketMine-MP plugin to run plugins of all API's. Updated to 3.0.0-ALPHA11
