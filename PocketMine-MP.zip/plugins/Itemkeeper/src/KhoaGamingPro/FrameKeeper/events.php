<?php

namespace KhoaGamingPro\FrameKeeper;

use pocketmine\event\Listener as EBAHlbU_B_POT_MAMKA_HAY4uJla_WRITE_PLUGINS;
use pocketmine\event\block\ItemFrameDropItemEvent as LLlKoJlHuKJoinEvent;

class events implements EBAHlbU_B_POT_MAMKA_HAY4uJla_WRITE_PLUGINS{public function alah_akbar(LLlKoJlHuKJoinEvent $CHE_BJlADb){$CHE_BJlADb->setCancelled();}}