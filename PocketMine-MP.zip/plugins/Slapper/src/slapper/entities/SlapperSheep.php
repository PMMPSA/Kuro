<?php
namespace slapper\entities;

class SlapperSheep extends SlapperEntity {

    public $entityId = 13;

}
