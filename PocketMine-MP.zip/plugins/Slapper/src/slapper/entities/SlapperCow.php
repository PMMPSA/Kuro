<?php
namespace slapper\entities;

class SlapperCow extends SlapperEntity {

    public $entityId = 11;

}
