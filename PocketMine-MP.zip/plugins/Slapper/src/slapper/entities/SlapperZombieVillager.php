<?php
namespace slapper\entities;

class SlapperZombieVillager extends SlapperEntity {

    public $entityId = 44;

}
