<?php
namespace slapper\entities;

class SlapperSilverfish extends SlapperEntity {

    public $entityId = 39;

}
