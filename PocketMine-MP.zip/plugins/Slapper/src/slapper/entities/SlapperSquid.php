<?php
namespace slapper\entities;

class SlapperSquid extends SlapperEntity {

    public $entityId = 17;

}
