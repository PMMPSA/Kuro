<?php
namespace slapper\entities;

class SlapperRabbit extends SlapperEntity {

    public $entityId = 18;

}