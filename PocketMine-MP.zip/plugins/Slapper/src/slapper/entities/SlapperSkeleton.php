<?php
namespace slapper\entities;

class SlapperSkeleton extends SlapperEntity {

    public $entityId = 34;

}
