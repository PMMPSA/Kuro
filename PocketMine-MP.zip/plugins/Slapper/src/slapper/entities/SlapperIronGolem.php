<?php
namespace slapper\entities;

class SlapperIronGolem extends SlapperEntity {

    public $entityId = 20;

}
