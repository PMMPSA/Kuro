<?php
namespace slapper\entities;

class SlapperDonkey extends SlapperEntity {

    public $entityId = 24;

}
