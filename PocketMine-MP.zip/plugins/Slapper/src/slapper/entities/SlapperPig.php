<?php
namespace slapper\entities;

class SlapperPig extends SlapperEntity {

    public $entityId = 12;

}
