<?php
namespace slapper\entities;

class SlapperSkeletonHorse extends SlapperEntity {

    public $entityId = 26;

}
