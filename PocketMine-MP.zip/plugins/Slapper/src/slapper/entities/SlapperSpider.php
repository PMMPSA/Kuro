<?php
namespace slapper\entities;

class SlapperSpider extends SlapperEntity {

    public $entityId = 35;

}
