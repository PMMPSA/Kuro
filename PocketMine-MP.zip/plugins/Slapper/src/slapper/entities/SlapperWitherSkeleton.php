<?php
namespace slapper\entities;

class SlapperWitherSkeleton extends SlapperEntity {

    public $entityId = 48;

}
