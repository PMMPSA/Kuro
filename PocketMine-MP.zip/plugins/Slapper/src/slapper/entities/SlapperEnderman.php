<?php
namespace slapper\entities;

class SlapperEnderman extends SlapperEntity {

    public $entityId = 38;

}
