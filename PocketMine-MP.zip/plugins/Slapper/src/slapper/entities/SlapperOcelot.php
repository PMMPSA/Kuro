<?php
namespace slapper\entities;

class SlapperOcelot extends SlapperEntity {

    public $entityId = 22;

}
