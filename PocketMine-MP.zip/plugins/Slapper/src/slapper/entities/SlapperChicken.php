<?php
namespace slapper\entities;

class SlapperChicken extends SlapperEntity {

    public $entityId = 10;

}
