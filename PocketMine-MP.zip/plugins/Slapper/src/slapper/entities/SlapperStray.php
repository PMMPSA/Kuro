<?php
namespace slapper\entities;

class SlapperStray extends SlapperEntity {

    public $entityId = 46;

}
