<?php
namespace slapper\entities;

class SlapperVillager extends SlapperEntity {

    public $entityId = 15;

}
