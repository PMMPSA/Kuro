<?php
namespace slapper\entities;

class SlapperHusk extends SlapperEntity {

    public $entityId = 47;

}
