<?php
namespace slapper\entities;

class SlapperGhast extends SlapperEntity {

    public $entityId = 41;

}
