<?php
namespace slapper\entities;

class SlapperMule extends SlapperEntity {

    public $entityId = 25;

}
