<?php
namespace slapper\entities;

class SlapperMushroomCow extends SlapperEntity {

    public $entityId = 16;

}
