<?php
namespace slapper\entities;

class SlapperSnowman extends SlapperEntity {

    public $entityId = 21;

}
