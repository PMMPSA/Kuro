<?php
namespace slapper\entities;

class SlapperCaveSpider extends SlapperEntity {

    public $entityId = 40;

}
