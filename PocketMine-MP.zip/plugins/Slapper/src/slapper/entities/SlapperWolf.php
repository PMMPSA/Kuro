<?php
namespace slapper\entities;

class SlapperWolf extends SlapperEntity {

    public $entityId = 14;

}
