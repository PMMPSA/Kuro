<?php
namespace slapper\entities;

class SlapperPigZombie extends SlapperEntity {

    public $entityId = 36;

}