<?php
namespace slapper\entities;

class SlapperZombie extends SlapperEntity {

    public $entityId = 32;

}