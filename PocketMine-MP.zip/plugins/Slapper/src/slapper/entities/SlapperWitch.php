<?php
namespace slapper\entities;

class SlapperWitch extends SlapperEntity {

    public $entityId = 45;

}
