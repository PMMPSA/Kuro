<?php
namespace slapper\entities;

class SlapperSlime extends SlapperEntity {

    public $entityId = 37;

}
