<?php
namespace slapper\entities;

class SlapperHorse extends SlapperEntity {

    public $entityId = 23;

}
