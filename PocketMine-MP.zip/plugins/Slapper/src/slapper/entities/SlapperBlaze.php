<?php
namespace slapper\entities;

class SlapperBlaze extends SlapperEntity {

    public $entityId = 43;

}
