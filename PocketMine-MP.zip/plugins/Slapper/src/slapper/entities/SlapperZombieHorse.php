<?php
namespace slapper\entities;

class SlapperZombieHorse extends SlapperEntity {

    public $entityId = 27;

}
