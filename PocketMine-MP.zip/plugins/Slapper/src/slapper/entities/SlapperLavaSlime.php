<?php
namespace slapper\entities;

class SlapperLavaSlime extends SlapperEntity {

    public $entityId = 42;

}
