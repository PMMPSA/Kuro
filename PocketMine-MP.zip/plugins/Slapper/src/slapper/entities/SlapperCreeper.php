<?php
namespace slapper\entities;

class SlapperCreeper extends SlapperEntity {

    public $entityId = 33;

}
