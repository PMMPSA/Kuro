<?php
namespace slapper\entities\other;

use pocketmine\network\protocol\AddEntityPacket;
use pocketmine\Player;
use slapper\entities\SlapperEntity;


class SlapperPrimedTNT extends SlapperEntity {

    public $entityId = 65;
    public $offset = 0.8;

}