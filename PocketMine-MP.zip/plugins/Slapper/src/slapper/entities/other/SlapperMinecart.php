<?php
namespace slapper\entities\other;

use slapper\entities\SlapperEntity;


class SlapperMinecart extends SlapperEntity {

    public $entityId = 84;
    public $offset = 0.3;

}
