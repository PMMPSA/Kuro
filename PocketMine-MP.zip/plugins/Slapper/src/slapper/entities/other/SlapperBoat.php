<?php
namespace slapper\entities\other;

use slapper\entities\SlapperEntity;


class SlapperBoat extends SlapperEntity {

    public $entityId = 90;
    public $offset = 0.2;

}
