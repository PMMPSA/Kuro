# Cách tải

+ Tải [tại đây](https://github.com/BlackZeroPM/VietHoa/wiki)
+ Sau đó khởi động lại máy chủ của bạn!

# Không hoạt động?

+ Bước 1: Vẫn tải plugin ở trên
+ Bước 2: Khởi động lại máy chủ của bạn
+ Bước 3: Tải tệp messages.ini [ở đây](https://github.com/BlackZeroPM/VietHoa/wiki)
+ Bước 4: Thả tệp đó vào thư mục plugin ManyWorlds của bạn

# Khác

Đóng góp, ý kiến hoặc báo lỗi? Liên hệ qua e-mail: pocketminevnp@gmail.com!
