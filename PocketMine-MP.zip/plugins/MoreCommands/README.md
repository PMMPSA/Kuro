MoreCommands a PocketMine-MP 1.4.1 Plugin by CrazedMiner (Jack Noordhuis).

Versions:
- v1.0- Realase, adds a bunch of new and hopefully usefull commands to your server.

To-do:
- Add config to toggle which commands are enabled.
- Add config to set the staff for the server.
- Add /staff command.
- Add /parkour command.
- Add /pvp command.
- Add /sethealth command.
- Add /inv <clear, see> command.
- Add /player lock <Player> command.
- Add /getpos command.
- Add /pos <Player> command.

Bugs:
- No known bugs.
